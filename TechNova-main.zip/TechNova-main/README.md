# TechNova
<html>
<head>
    <title>www.technova.com</title>
</head>
<body>
    <h1>TechNova</h1>
</body>
</html>

<ul>
    <h3>Services Offered By TechNova</h3>
        <li>Web Develpment</li>
        <li>Mobile App Develpment</li>
        <li>Cloud Solutions</li>
    </ul><br />

<p>Contact TechNova Here:</p>

<address>
    <a href="mailto:info@technova.com">info@technova</a><br/>
    <a href="tel:+123-456-7890">123-456-7890</a><br/>
    You Can Also Visit Us At:<br />
    UX Lab Street<br />
    Lewisham Way<br />
    London<br />
</address>
